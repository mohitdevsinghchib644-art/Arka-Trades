# Arka MONEY FLOW v7 — install and notes

A replacement for the Money Flow page. Entry point is unchanged: `render_money_flow(on_open=None)`.

## Install (3 steps)

1. In the Arka project folder, rename the current `money_flow.py` to `money_flow_v6_backup.py`.
2. Copy `money_flow.py` and the whole `arka_flow/` folder from this zip into the project folder,
   next to `mf_ui.py` and `sector_map.py`. Both of those existing files are still required, unchanged.
3. Run the app as usual. Open MONEY FLOW and press **LOAD SECTOR DATA**.

No new Python packages are needed. Optional: copy `tests/` too and run `python -m pytest tests -q` (31 tests).

Files Money Flow no longer uses: `rotation_engine.py`, `flow_engine.py`, `sector_engine.py`. Leave them in
place if other pages import them. `rotation_lab.py` still runs on the old formulas; its labels do not match
this page and should not be relied on.

## What the page shows

| View | Content |
| --- | --- |
| OVERVIEW | Market breadth, sector counts by state, the state board with evidence per sector, recent state changes, contradictions, relative-strength distribution |
| SECTOR DETAIL | State with supporting / contradicting / missing evidence, FACT / INFERENCE / UNKNOWN explanation, level and relative-strength charts, every horizon against every benchmark, breadth history, state history, what followed this state historically, constituents with setups, structured data for Arka AI |
| RANKING | Every sector, sortable, three column sets, CSV download |
| BREADTH | Level and direction as separate columns, whole-market breadth |
| ACTIVITY | Traded value, relative activity, up-close and down-close turnover share |
| SIGNAL TESTS | What followed each state on the loaded history: forward excess return at 5/10/20/40/60 sessions, beat rate, worst point, two-half stability check, comparison with simple alternatives, round-trip cost |
| FPI FLOWS | NSDL fortnightly FPI net investment by sector, with staleness shown |
| DATA & METHOD | What loaded, every failed ticker, coverage per sector, large one-day moves, the full state rules and formulas |

Sector lists: **ARKA GROUPS** (the groups in `sector_map.py`, equal-weight baskets) or **NSE INDICES**
(official index levels). Benchmarks: NIFTY 500, NIFTY 50, or an equal-weight market basket.

## How a state is decided

The rules are in `arka_flow/state.py` and are printed in full on the DATA & METHOD view. In short:

- **LEADERSHIP**: ahead of the benchmark over 60 sessions, above its own 50-EMA, relative-strength trend not down.
- **MATURE LEADERSHIP**: still a leader, with two or more of: extended, slowing, breadth falling, 20-session RS negative.
- **DETERIORATION**: 20-session RS negative and RS trend down, confirmed by breadth or price.
- **EARLY IMPROVEMENT / PARTICIPATION CONFIRMATION / RECOVERY**: behind over 60 sessions but turning, split by
  whether price is above its 50-EMA and whether more stocks are joining.
- A new state is shown only after it holds for 3 completed sessions. Today's unfinished session is never used.

There is no BUY / HOLD / AVOID / EXIT label. A state is a description; SIGNAL TESTS shows what it was followed by.

## Tested and not tested

Tested here:
- 31 unit and integration tests of every formula, the state rules, the signal tests and the loader.
- The whole page was run through every view, both sector lists and all three benchmarks using a stand-in
  for Streamlit and simulated prices, including failed tickers, a missing benchmark and a part-day bar.

Not tested here (this workspace has no Streamlit, plotly or internet):
- Rendering in real Streamlit, and the plotly charts. If a plotly chart fails, the page falls back to
  Streamlit's built-in line chart instead of crashing.
- The live Yahoo download and the NSDL download.
- HOME's rotation panel. The page still publishes `st.session_state["mf_rot"]` with the same columns, but the
  `action` column now holds state names (LEADERSHIP, DETERIORATION, ...) instead of the v6 labels.

If anything errors on first run, send the traceback.

## Not in this build

Shown as NOT AVAILABLE or unknown, never estimated:
- Delivery quantity and delivery % (the NSE bhavcopy parser is in `arka_flow/data/sources.py` but is not wired in).
- Exchange-reported traded value (close x volume is used and labelled approximate).
- Mutual-fund and other domestic institutional data, bulk and block deals.
- Fundamentals, earnings revisions, macro context.
- Point-in-time index membership: today's member lists are applied to history (survivorship bias).
- Saving daily snapshots to the SQLite store (`arka_flow/data/store.py` exists and is tested, but the page does
  not write to it yet).
- A live AI call. The page produces the structured FACT / UNKNOWN object for Arka AI; connecting it needs
  Arka AI's code.

Every threshold in the state rules is provisional until the SIGNAL TESTS view has been read on real data.
