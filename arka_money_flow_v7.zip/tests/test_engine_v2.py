"""Tests for the history panels, state machine, signal tests, loader and report tables."""
import math
import numpy as np, pandas as pd, pytest
from arka_flow import history, state as st, backtest as bt, report, loader

D = lambda n, end="2026-11-13": pd.bdate_range(end=end, periods=n)

def universe(seed=1, n=520, per=8):
    rng = np.random.default_rng(seed); idx = D(n)
    mkt = rng.normal(0.0004, 0.008, n)
    def grp(drift):                       # drift may be an array (regime change)
        return {None: None} and [100 * np.cumprod(1 + mkt + drift + rng.normal(0, 0.010, n)) for _ in range(per)]
    up = np.full(n, 0.0012); dn = np.full(n, -0.0012)
    turn = np.r_[np.full(n - 60, -0.0015), np.full(60, 0.0030)]          # lagging for long, then turning up
    fade = np.r_[np.full(n - 60, 0.0015), np.full(60, -0.0030)]
    spec = {"STRONG": up, "WEAK": dn, "TURNING": turn, "FADING": fade, "FLAT1": np.zeros(n), "FLAT2": np.zeros(n)}
    close, members = {}, {}
    for g, d in spec.items():
        for i, s in enumerate(grp(d)):
            close[f"{g}{i}"] = s; members.setdefault(g, []).append(f"{g}{i}")
    close = pd.DataFrame(close, index=idx)
    vol = pd.DataFrame(rng.integers(1e5, 1e6, close.shape).astype(float), index=idx, columns=close.columns)
    bench = pd.Series(100 * np.cumprod(1 + mkt), index=idx)
    return close, vol, members, bench

@pytest.fixture(scope="module")
def U():
    close, vol, members, bench = universe()
    H = history.build(close, vol, members, bench); H["bench_name"] = "NIFTY 500"
    return close, vol, members, bench, H, st.classify(H)

def test_history_is_point_in_time(U):
    close, vol, members, bench, H, cl = U
    cut = close.index[-40]
    H2 = history.build(close.loc[:cut], vol.loc[:cut], members, bench.loc[:cut])
    for k in ("rel_20", "rel_60", "pctile_20", "pct50", "ext_pctile", "up_share5", "ratio_sma50"):
        pd.testing.assert_series_equal(H[k].loc[cut], H2[k].loc[cut], check_names=False)        # future data changes nothing
    s2 = st.classify(H2)["state"]
    pd.testing.assert_frame_equal(cl["state"].loc[:cut], s2)

def test_states_match_the_regimes(U):
    *_, H, cl = U
    last = cl["state"].iloc[-1]
    assert last["STRONG"] in ("LEADERSHIP", "MATURE LEADERSHIP")
    assert last["WEAK"] in ("DETERIORATION", "NO CLEAR STATE", "RECOVERY")
    assert last["TURNING"] in ("EARLY IMPROVEMENT", "PARTICIPATION CONFIRMATION", "RECOVERY", "LEADERSHIP", "MATURE LEADERSHIP")
    turn = cl["state"]["TURNING"]
    assert (turn.iloc[300:440] == "DETERIORATION").mean() > 0.5 and turn.iloc[-1] != "DETERIORATION"   # lagging for long, then a leader
    assert last["FADING"] in ("DETERIORATION", "MATURE LEADERSHIP", "NO CLEAR STATE")
    share = (cl["state"]["STRONG"].iloc[300:].isin(["LEADERSHIP", "MATURE LEADERSHIP"])).mean()
    assert share > 0.7                                                     # a persistent out-performer stays a leader
    assert not (cl["state"]["STRONG"].iloc[300:] == "DETERIORATION").mean() > 0.05

def test_audit_case_steady_outperformer_slowing_is_never_deterioration():
    n = 400; idx = D(n)
    b = pd.Series(100 * np.cumprod(np.full(n, 1.0005)), index=idx)
    ex = np.linspace(0.0020, 0.0006, n)
    close = pd.DataFrame({f"S{i}": 100 * np.cumprod(1.0005 + ex * (0.9 + 0.04 * i)) for i in range(6)} |
                         {f"M{i}": b.to_numpy() * (1 + 0.001 * i) for i in range(6)} |
                         {f"L{i}": 100 * np.cumprod(np.full(n, 1.0001 + 0.00002 * i)) for i in range(6)}, index=idx)
    vol = pd.DataFrame(1e5, index=idx, columns=close.columns)
    mem = {"S": [f"S{i}" for i in range(6)], "M": [f"M{i}" for i in range(6)], "L": [f"L{i}" for i in range(6)]}
    H = history.build(close, vol, mem, b); cl = st.classify(H)
    s = cl["state"]["S"].iloc[150:]
    assert set(s.unique()) <= {"LEADERSHIP", "MATURE LEADERSHIP"}, s.value_counts().to_dict()
    ev = st.evidence(H, cl, "S")
    assert ev["n_support"] >= 3 and any("60-session return vs benchmark +" in x for x in ev["supporting"])

def test_persistence_needs_k_sessions():
    idx = D(8)
    raw = pd.DataFrame({"A": ["X", "X", "Y", "X", "Y", "Y", "Y", "Y"], "B": [st.NOHIST] * 3 + ["X"] * 5}, index=idx)
    out = st.persist(raw, 3)
    assert out["A"].tolist() == ["X", "X", "X", "X", "X", "X", "Y", "Y"]
    assert out["B"].tolist() == [st.NOHIST] * 3 + ["X"] * 5
    tr = st.transitions(out)
    assert tr.at["A", "previous"] == "X" and tr.at["A", "sessions"] == 2 and tr.at["B", "previous"] == ""

def test_forward_returns_enter_next_session_not_signal_close():
    idx = D(8)
    L = pd.DataFrame({"A": [100, 200, 100, 110, 121, 100, 100, 100.0]}, index=idx)
    b = pd.Series(100.0, index=idx)
    exc, absr, mae, mfe = bt.forward_panels(L, b, h=2)
    assert absr["A"].iloc[1] == pytest.approx(21.0)        # signal at t=1 (200): entry t=2 at 100, exit t=4 at 121
    assert exc["A"].iloc[1] == pytest.approx(21.0)
    assert mfe["A"].iloc[1] == pytest.approx(21.0) and mae["A"].iloc[1] == pytest.approx(10.0)
    assert math.isnan(absr["A"].iloc[-3])                   # not enough future sessions: NaN, never a guess

def test_state_table_and_baselines(U):
    *_, H, cl = U
    t = bt.state_table(cl["state"], H["levels"], H["bench"], horizons=(20,), mode="all")
    lead = t[t.state.isin(["LEADERSHIP", "MATURE LEADERSHIP"])]
    assert lead["n"].sum() > 10 and (t["n"] >= 0).all() and {"mean", "beat_pct", "mae", "mfe", "t_stat"} <= set(t.columns)
    e = bt.state_table(cl["state"], H["levels"], H["bench"], horizons=(5, 20), mode="entries")
    assert len(e) and e["horizon"].nunique() == 2
    bl = bt.baseline_table(H, cl["state"], 20)
    assert bl.selection.str.startswith("Top third").sum() == 3 and bl.selection.iloc[0].startswith("All sectors")
    cut = bt.split_point(cl["state"].index)
    a = bt.state_table(cl["state"], H["levels"], H["bench"], (20,), "all", end=cut)
    b = bt.state_table(cl["state"], H["levels"], H["bench"], (20,), "all", start=cut)
    assert a["n"].sum() > 0 and b["n"].sum() > 0
    ss = bt.state_stats(cl["state"])
    assert ss["share_of_time_pct"].sum() == pytest.approx(100.0)
    c = bt.round_trip_cost()
    assert 0.3 < c["total_pct"] < 0.4 and c["stt"] == pytest.approx(0.2)

def test_sector_table_stock_table_payload(U):
    close, vol, members, bench, H, cl = U
    tb = report.sector_table(H, cl)
    assert len(tb) == 6 and tb.pctile_20.max() == pytest.approx(100.0) and (tb.coverage_status == "ok").all()
    row = tb[tb.sector == "STRONG"].iloc[0].to_dict()
    assert row["rel_60"] > 0 and row["since"] <= H["asof"] and row["evidence"]["state"] == row["state"]
    txt = report.explain(row, "NIFTY 500")
    assert "**FACT.**" in txt and "**UNKNOWN:**" in txt
    assert not any(w in txt.upper() for w in ("BUY", "SELL", "AVOID", "EXIT", "FATIGUE"))
    p = report.ai_payload(row, H["asof"], "NIFTY 500", "Yahoo")
    assert p["FACT"]["measurements"]["rel_60"] == round(row["rel_60"], 2) and "who bought or sold" in p["UNKNOWN"]
    stk = report.stock_table(close, close, vol, members["STRONG"], bench, H["levels"]["STRONG"])
    assert len(stk) == 8 and stk["setup"].notna().all() and stk["rel_bench_60"].is_monotonic_decreasing

def test_missing_breadth_is_reported_not_guessed(U):
    close, vol, members, bench, H, cl = U
    levels = H["levels"][["STRONG", "WEAK", "TURNING"]].rename(columns=lambda c: "IDX_" + c)     # index series without members
    H2 = history.build(close, vol, {}, bench, levels=levels); c2 = st.classify(H2)
    assert H2["pct50"].isna().all().all()
    ev = st.evidence(H2, c2, "IDX_STRONG")
    assert ev["state"] in ("LEADERSHIP", "MATURE LEADERSHIP") and ev["n_missing"] >= 1 and ev["confidence"] != "HIGH"
    tb = report.sector_table(H2, c2)
    assert (tb.coverage_status == "NO MEMBERS").all()

def test_loader_reports_failures_retries_and_flags():
    idx = D(30)
    def frame(v, last=None):
        f = pd.DataFrame({"Close": v, "High": v * 1.01, "Low": v * 0.99, "Volume": 1000.0}, index=idx if last is None else idx[:last])
        return f
    calls = []
    def fetch(tickers, period):
        calls.append(list(tickers))
        if len(calls) == 1:
            raise ConnectionError("rate limited")                     # whole first batch fails
        out = {}
        for t in tickers:
            if t == "DEAD.NS":
                continue
            v = pd.Series(np.linspace(100, 110, 30), index=idx)
            if t == "JUMP.NS":
                v.iloc[20:] *= 2
            f = frame(v) if t != "OLD.NS" else frame(v.iloc[:10], 10)
            out[t] = f
        return pd.concat(out, axis=1)
    P = loader.load_prices(["A", "B", "DEAD", "JUMP", "OLD"], ["^NSEI"], fetch=fetch, period="1mo")
    assert len(calls) == 2 and set(P["failures"]) == {"DEAD.NS"}             # retried, and the failure is named
    assert P["stale"] == ["OLD"] and "OLD" not in P["close"].columns
    assert P["jumps"] and P["jumps"][0]["symbol"] == "JUMP" and P["close"]["JUMP"].iloc[-1] == pytest.approx(220.0)   # listed, not altered
    assert list(P["index"].columns) == ["^NSEI"] and P["requested"] == 5
    P2, dropped = loader.drop_partial_session(P, str(idx[-2].date()))
    assert dropped == [str(idx[-1].date())] and P2["close"].index[-1] == idx[-2] and P2["index"].index[-1] == idx[-2]
