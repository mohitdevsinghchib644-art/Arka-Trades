"""Unit + integration tests for arka_flow. Run from the folder that contains arka_flow/:  python -m pytest -q"""
import math, sys, types
from datetime import datetime
import numpy as np, pandas as pd, pytest

from arka_flow.calc import relative_strength as rs, breadth, activity, conditions
from arka_flow.data import validation as val, sources
from arka_flow.data.store import Store
from arka_flow import engine, universe

D = lambda n, end="2026-11-13": pd.bdate_range(end=end, periods=n)

# ───────────── relative strength ─────────────
def test_relative_return_and_ratio_change_are_different_and_both_right():
    idx = D(6)
    lv = pd.DataFrame({"S": [100, 100, 100, 100, 100, 110.0]}, index=idx)
    b = pd.Series([100, 100, 100, 100, 100, 105.0], index=idx)
    t = rs.rs_table(lv, b, horizons=(5,))
    assert t.at["S", "abs_5"] == pytest.approx(10.0)
    assert t.at["S", "bench_5"] == pytest.approx(5.0)
    assert t.at["S", "rel_5"] == pytest.approx(5.0)                       # percentage points
    assert t.at["S", "ratio_chg_5"] == pytest.approx((1.10 / 1.05 - 1) * 100)   # 4.76 %

def test_insufficient_history_is_nan_not_zero():
    idx = D(10)
    lv = pd.DataFrame({"S": np.linspace(100, 110, 10)}, index=idx)
    t = rs.rs_table(lv, pd.Series(100.0, index=idx), horizons=(5, 20))
    assert not math.isnan(t.at["S", "rel_5"]) and math.isnan(t.at["S", "rel_20"])

def test_sessions_align_on_benchmark_dates_without_filling():
    idx = D(8)
    lv = pd.DataFrame({"S": [100, 101, 102, 103, 104, 105, 106, 107.0]}, index=idx)
    b = pd.Series([100, 100, 100, 100, 100, 100, 100.0], index=idx.delete(3))   # benchmark missing one session
    a, br, rel, rc = rs.relative_panels(lv, b, 2)
    assert len(a) == 7 and idx[3] not in a.index
    assert a["S"].iloc[-1] == pytest.approx((107 / 105 - 1) * 100)

def test_duplicate_or_unsorted_dates_raise():
    idx = D(5)
    lv = pd.DataFrame({"S": range(1, 6)}, index=idx.append(idx[-1:]) [:5].insert(0, idx[0])[:5])
    with pytest.raises(ValueError):
        rs.rs_table(lv, pd.Series(1.0, index=idx))
    with pytest.raises(ValueError):
        rs.rs_table(pd.DataFrame({"S": [1.0, 2, 3]}, index=idx[:3][::-1]), pd.Series(1.0, index=idx))

def test_percentile_uses_full_universe_and_reports_n():
    idx = D(6)
    lv = pd.DataFrame({f"S{i}": [100] * 5 + [100 + i] for i in range(10)}, index=idx, dtype=float)
    lv["SHORT"] = [np.nan] * 5 + [100.0]                                    # no history: must not be ranked
    t = rs.rs_table(lv, pd.Series(100.0, index=idx), horizons=(5,))
    assert t.at["S9", "pctile_5"] == pytest.approx(100.0) and t.at["S0", "pctile_5"] == pytest.approx(10.0)
    assert t["n_ranked_5"].iloc[0] == 10 and math.isnan(t.at["SHORT", "pctile_5"])

def test_steady_outperformer_is_trend_up_not_weak():
    n = 400; idx = D(n)
    b = pd.Series(100 * np.cumprod(np.full(n, 1.0005)), index=idx)
    s = pd.Series(100 * np.cumprod(1.0005 + np.linspace(0.0020, 0.0006, n)), index=idx)   # the audit's case A
    lv = pd.DataFrame({"S": s, "FLAT": b * 1.0, "LAG": 100 * np.cumprod(np.full(n, 1.0001))}, index=idx)
    d = rs.rs_dynamics(lv, b)
    assert d.at["S", "rs_trend"] == "up" and d.at["S", "rs_accel"] < 0        # slowing AND still trending up
    assert d.at["LAG", "rs_trend"] == "down"

def test_leadership_status_rules():
    f = rs.leadership_status
    assert f(90, 40, 0.3) == "new leadership"
    assert f(90, 85, 0.8) == "persistent leadership"
    assert f(70, 95, 0.9) == "weakening leadership"
    assert f(50, 80, 0.5) == "lost leadership"
    assert f(50, 20, 0.0) == "recovering"
    assert f(None, 20, 0.0) is None

# ───────────── breadth ─────────────
def _breadth_fixture():
    idx = D(260)
    up, dn = np.linspace(100, 200, 260), np.linspace(200, 100, 260)
    c = pd.DataFrame({"A": up, "B": up * 1.1, "C": dn, "D": dn * 0.9}, index=idx)
    c.loc[idx[-1], "D"] = np.nan                                           # D has no bar today
    return c

def test_breadth_counts_and_denominators():
    p = breadth.breadth_panel(_breadth_fixture(), ["A", "B", "C", "D", "NOT_LOADED"])
    last = p.iloc[-1]
    assert last["n_members"] == 5 and last["n_with_bar"] == 3
    assert last["pct_above_ema50"] == pytest.approx(200 / 3)               # A, B above; C below; D excluded
    assert last["adv"] == 2 and last["dec"] == 1 and last["unch"] == 0
    assert last["new_high_252"] == 2 and last["new_low_252"] == 1 and last["new_high_20"] == 2
    assert last["breakout_20"] == 2 and last["breakdown_20"] == 1

def test_breadth_short_history_is_not_counted():
    c = _breadth_fixture().tail(30)
    last = breadth.breadth_panel(c, list("ABCD")).iloc[-1]
    assert last["eligible_above_ema200"] == 0 and math.isnan(last["pct_above_ema200"])
    assert last["eligible_252"] == 0 and last["new_high_252"] == 0

def test_breadth_level_and_direction_are_separate():
    idx = D(120)
    base = np.r_[np.linspace(100, 150, 100), np.linspace(150, 149, 20)]
    c = pd.DataFrame({f"S{i}": base for i in range(10)}, index=idx)
    c.loc[idx[-10:], ["S0", "S1"]] = c.loc[idx[-10:], ["S0", "S1"]] * 0.7      # 2 of 10 break down
    s = breadth.snapshot(breadth.breadth_panel(c, list(c.columns)))
    assert s["pct_above_ema50"] == pytest.approx(80.0)                     # level still high
    assert s["pct_above_ema50_chg20"] == pytest.approx(-20.0)              # direction down
    assert s["pct_above_ema50_chg20_stocks"] == pytest.approx(-2.0) and s["one_stock_points"] == pytest.approx(10.0)

# ───────────── activity ─────────────
def test_up_down_share_and_relative_activity():
    idx = D(25)
    c = pd.DataFrame({"A": np.arange(100, 125.0), "B": np.arange(125, 100.0, -1)}, index=idx)
    v = pd.DataFrame({"A": 10.0, "B": 10.0}, index=idx); v.iloc[-1] = [30.0, 10.0]
    tv = pd.DataFrame({"A": 300.0, "B": 100.0}, index=idx); tv.iloc[-1] = [900.0, 100.0]
    p = activity.activity_panel(c, v, ["A", "B"], traded_value=tv)
    last = p.iloc[-1]
    assert last["up_close_tv_share"] == pytest.approx(90.0) and last["down_close_tv_share"] == pytest.approx(10.0)
    assert last["relative_activity"] == pytest.approx(1000 / 400)          # baseline excludes today
    assert p.attrs["value_basis"] == "exchange-reported"
    assert math.isnan(last["deliverable_qty_ratio"]) and math.isnan(last["n_up_price_up_deliv"])   # NOT AVAILABLE, not 0

def test_activity_without_exchange_value_is_labelled_approximate_and_delivery_ratio():
    idx = D(25)
    c = pd.DataFrame({"A": np.arange(100, 125.0)}, index=idx); v = pd.DataFrame({"A": 100.0}, index=idx)
    d = pd.DataFrame({"A": 40.0}, index=idx)
    p = activity.activity_panel(c, v, ["A"], deliv_qty=d)
    assert p.attrs["value_basis"].startswith("approximate") and p["deliverable_qty_ratio"].iloc[-1] == pytest.approx(40.0)

def test_cmf_standard_known_value():
    idx = D(3)
    f = lambda x: pd.DataFrame({"A": x}, index=idx, dtype=float)
    cmf = activity.cmf_standard(f([10, 10, 10]), f([8, 8, 10]), f([10, 8, 10]), f([100, 100, 100]), n=3)
    assert cmf["A"].iloc[-1] == pytest.approx((100 - 100 + 0) / 300)       # +1, -1, 0 (H == L) multipliers

# ───────────── validation ─────────────
def test_clean_series_counts_everything_and_fills_nothing():
    idx = pd.to_datetime(["2026-11-03", "2026-11-02", "2026-11-03", "2026-11-04", "2026-11-05", "2026-11-06"])
    s, q = val.clean_series(pd.Series([100, 99, 101, 0, np.nan, 140.0], index=idx), "X", "test")
    assert q.duplicates_dropped == 1 and q.was_unsorted and q.non_positive == 1 and q.missing == 2
    assert s.isna().sum() == 2 and q.status == "warning" and q.last_date == "2026-11-06"
    s2, q2 = val.clean_series(pd.Series([100, 50.0], index=D(2)), "Y", "test")
    assert q2.jumps and q2.jumps[0]["move_pct"] == -50.0 and s2.iloc[-1] == 50.0      # listed, not altered
    assert val.clean_series(pd.Series(dtype=float), "Z", "test")[1].status == "failed"

def test_session_state_partial_weekend_holiday():
    ist = val.IST
    st = val.session_state(datetime(2026, 11, 13, 11, 0, tzinfo=ist))      # Friday mid-session
    assert st["market_open"] and st["today_partial"] and st["last_complete_session"] == "2026-11-12"
    st = val.session_state(datetime(2026, 11, 13, 16, 0, tzinfo=ist))
    assert not st["market_open"] and st["last_complete_session"] == "2026-11-13"
    st = val.session_state(datetime(2026, 11, 15, 12, 0, tzinfo=ist))      # Sunday
    assert not st["market_open"] and st["last_complete_session"] == "2026-11-13"
    from datetime import date
    st = val.session_state(datetime(2026, 11, 13, 12, 0, tzinfo=ist), holidays={date(2026, 11, 13)})
    assert not st["market_open"] and st["last_complete_session"] == "2026-11-12" and st["holiday_calendar"] == "supplied"

def test_stale_sessions():
    assert val.stale_sessions("2026-11-13", "2026-11-13") == 0
    assert val.stale_sessions("2026-11-10", "2026-11-13") == 3
    assert val.stale_sessions(None, "2026-11-13") is None

# ───────────── sources + store ─────────────
BHAV = """SYMBOL, SERIES, DATE1, PREV_CLOSE, OPEN_PRICE, HIGH_PRICE, LOW_PRICE, LAST_PRICE, CLOSE_PRICE, AVG_PRICE, TTL_TRD_QNTY, TURNOVER_LACS, NO_OF_TRADES, DELIV_QTY, DELIV_PER
SBIN, EQ, 13-Nov-2026, 800.00, 801.00, 812.00, 799.00, 810.00, 810.50, 806.00, 1000000, 80600.00, 50000, 600000, 60.00
SBIN, BL, 13-Nov-2026, 800.00, 805.00, 805.00, 805.00, 805.00, 805.00, 805.00, 5000, 40.25, 1, -, -
XYZ, BE, 13-Nov-2026, 10.00, 10.00, 10.50, 9.90, 10.40, 10.40, 10.20, 2000, 0.20, 12, -, -
"""
def test_bhavcopy_parser():
    df = sources.parse_bhavcopy(BHAV)
    assert list(df.index) == ["XYZ", "SBIN"] or set(df.index) == {"SBIN", "XYZ"}
    assert df.at["SBIN", "close"] == 810.5 and df.at["SBIN", "traded_value"] == pytest.approx(80600 * 1e5)
    assert df.at["SBIN", "deliv_qty"] == 600000 and math.isnan(df.at["XYZ", "deliv_qty"])      # '-' is NaN, not 0
    with pytest.raises(ValueError):
        sources.parse_bhavcopy("SYMBOL,SERIES,CLOSE\nA,EQ,1\n")
    assert sources.bhav_url(pd.Timestamp("2026-11-13")).endswith("sec_bhavdata_full_13112026.csv")

def test_store_roundtrip_is_idempotent_and_keeps_nulls(tmp_path):
    st = Store(tmp_path / "t.db")
    df = pd.DataFrame({"close": [1.0, np.nan, 3.0], "volume": [10, 20, 30.0]}, index=D(3))
    assert st.upsert_prices("A", "yahoo", df, "adjusted", "now") == 3
    st.upsert_prices("A", "yahoo", df.tail(1), "adjusted", "later")       # incremental re-load of the last day
    got = st.load_prices(["A"], "yahoo", "close")
    assert len(got) == 3 and math.isnan(got["A"].iloc[1]) and st.last_date("A", "yahoo") == str(D(3)[-1].date())
    st.log_quality(val.clean_series(df["close"], "A", "yahoo")[1])
    st.save_snapshot("S", "2026-11-13", "0.1.0", "NIFTY 500", "now", {"rel_20": 1.5, "x": float("nan")})
    rid = st.start_run("0.1.0", "now"); st.finish_run(rid, "now", "ok", {"errors": []})

def test_custom_sectors_come_from_sector_map(monkeypatch):
    fake = types.ModuleType("sector_map")
    fake.GROUPS = {"PSU Banks": ("Financials", "SBIN PNB CANBK IDBI"), "Tiny": ("X", "A B")}
    monkeypatch.setitem(sys.modules, "sector_map", fake)
    cs = universe.custom_sectors()
    assert [c.name for c in cs] == ["PSU Banks"] and cs[0].kind == "CUSTOM" and "IDBI" in cs[0].members
    assert cs[0].survivorship_note and universe.official_sectors()[0].kind == "OFFICIAL"

# ───────────── conditions ─────────────
def test_describe_separates_the_situations():
    d = conditions.describe
    base = {"bench": "NIFTY 500", "n_stocks": 12}
    a = d({**base, "abs_20": 6, "abs_60": 15, "rel_20": 3, "rel_60": 9, "pct_above_ema50": 83, "breadth_chg20_stocks": 0, "ext_pctile": 95})
    names = [s["name"] for s in a["situations"]]
    assert "Rising with strong and broad participation" in names and "Extended but still strongly trending" in names
    assert not a["contradictions"]
    b = d({**base, "abs_20": 2, "abs_60": 10, "rel_20": -1.5, "rel_60": 4, "pct_above_ema50": 70, "breadth_chg20_stocks": -1})
    assert [s["name"] for s in b["situations"]] == ["Rising but losing relative strength"]
    assert b["breadth_direction"] == "steady"                              # one stock is not a trend
    assert b["contradictions"][0]["name"] == "Price rising, relative strength falling"
    c = d({**base, "abs_20": 4, "abs_60": 12, "rel_20": 2, "rel_60": 6, "pct_above_ema50": 50, "breadth_chg20_stocks": -4, "ew_minus_index_60": -9})
    n = [s["name"] for s in c["situations"]]
    assert "Rising and strengthening" in n and "Rising but breadth is deteriorating" in n
    assert {x["name"] for x in c["contradictions"]} == {"Price rising, breadth falling", "Strong index performance, weak equal-weight performance"}
    e = d({**base, "abs_20": -3, "abs_60": -8, "rel_20": 1, "rel_60": -4, "pct_above_ema50": 30, "breadth_chg20_stocks": 3})
    assert e["situations"][0]["name"] == "Falling but showing early improvement"
    f = d({**base, "abs_20": -3, "abs_60": -8, "rel_20": -2, "rel_60": -4, "pct_above_ema50": 20, "breadth_chg20_stocks": -3})
    assert f["situations"][0]["name"] == "Falling and deteriorating further"
    g = d({**base, "abs_20": 1, "abs_60": -2, "rel_20": 2, "rel_60": 1})
    assert g["situations"][0]["name"] == "Consolidating while relative strength improves" and "pct_above_ema50" in g["missing"]
    assert d({"abs_20": None})["missing"] and not d({"abs_20": None})["situations"]
    text = str([a, b, c, e, f, g]).upper()
    assert not any(w in text for w in ("BUY", "SELL", "AVOID", "EXIT", "FATIGUE", "DISTRIBUTION"))

# ───────────── integration ─────────────
def _universe(seed=5, n=420):
    rng = np.random.default_rng(seed); idx = D(n)
    mk = lambda dr, vol=0.012: 100 * np.cumprod(1 + rng.normal(dr, vol, n))
    close = pd.DataFrame({f"P{i}": mk(0.0015) for i in range(6)} | {f"Q{i}": mk(-0.0005) for i in range(6)} |
                         {f"R{i}": mk(0.0004) for i in range(6)}, index=idx)
    vol = pd.DataFrame(rng.integers(1e5, 1e6, close.shape).astype(float), index=idx, columns=close.columns)
    bench = pd.Series(mk(0.0004, 0.008), index=idx)
    members = {"STRONG": [f"P{i}" for i in range(6)] + ["GONE1", "GONE2"], "WEAK": [f"Q{i}" for i in range(6)],
               "MID": [f"R{i}" for i in range(6)]}
    levels = pd.DataFrame({k: engine.equal_weight_level(close, m) for k, m in members.items()})
    return levels, bench, members, close, vol

def test_pipeline_end_to_end_reports_coverage_trace_and_is_reproducible():
    args = _universe()
    r1 = engine.compute_sector_report(*args[:2], "NIFTY 500", *args[2:], sources={"STRONG": "equal-weight basket"})
    r2 = engine.compute_sector_report(*args[:2], "NIFTY 500", *args[2:], sources={"STRONG": "equal-weight basket"})
    s = r1["sectors"]["STRONG"]
    assert s["coverage"]["missing"] == ["GONE1", "GONE2"] and s["coverage"]["status"] == "INCOMPLETE"   # 6 of 8 = 75%
    assert r1["sectors"]["WEAK"]["coverage"]["status"] == "ok" and r1["n_sectors_ranked_20"] == 3
    assert s["facts"]["rel_60"] > 0 > r1["sectors"]["WEAK"]["facts"]["rel_60"]
    assert s["facts"]["rs_trend"] in ("up", "mixed") and s["activity_value_basis"].startswith("approximate")
    tr = s["trace"]["rel_60"]
    assert tr["value"] == s["facts"]["rel_60"] and tr["asof"] == r1["asof"] and tr["level_source"] == "equal-weight basket"
    assert s["trace"]["pct_above_ema50"]["value"] == s["facts"]["breadth_pct_above_ema50"]
    assert s["trace"]["up_close_tv_share_5"]["value"] == s["facts"]["act_up_close_tv_share_5"]
    assert math.isnan(s["facts"]["act_deliverable_qty_ratio"])
    for k in r1["sectors"]:                                                # same input, same output
        pd.testing.assert_series_equal(pd.Series(r1["sectors"][k]["facts"]), pd.Series(r2["sectors"][k]["facts"]))

def test_equal_weight_level_skips_missing_bars_and_does_not_fill():
    idx = D(4)
    c = pd.DataFrame({"A": [100, 110, np.nan, 121.0], "B": [100, 100, 100, 100.0]}, index=idx)
    lv = engine.equal_weight_level(c, ["A", "B", "ABSENT"])
    assert math.isnan(lv.iloc[0]) and lv.iloc[1] == pytest.approx(105.0)   # (10% + 0%) / 2
    assert lv.iloc[2] == pytest.approx(105.0) and lv.iloc[3] == pytest.approx(105.0)   # A has no 1-day return on either side of its gap
